import React from "react";

function App() {
  return <h1>Hello from React!</h1>;
}

export default App;
